/**
 * Main JavaScript file for Katering Paramitha Wijaya Sejahtera website
 * Author: Manus AI
 * Date: April 2025
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all components
    initMobileMenu();
    initMenuFilter();
    initTestimonialSlider();
    initScrollAnimation();
    initFormValidation();
    initHeaderScroll();
});

/**
 * Mobile Menu Toggle
 */
function initMobileMenu() {
    const menuToggle = document.querySelector('.mobile-menu-toggle');
    const mainNav = document.querySelector('.main-nav');
    
    if (menuToggle && mainNav) {
        menuToggle.addEventListener('click', function() {
            mainNav.classList.toggle('active');
            
            // Toggle hamburger animation
            const spans = menuToggle.querySelectorAll('span');
            spans.forEach(span => span.classList.toggle('active'));
            
            // If menu is open, add event listener to close when clicking outside
            if (mainNav.classList.contains('active')) {
                document.addEventListener('click', closeMenuOnClickOutside);
            } else {
                document.removeEventListener('click', closeMenuOnClickOutside);
            }
        });
        
        // Close menu when clicking on a nav link
        const navLinks = mainNav.querySelectorAll('a');
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                mainNav.classList.remove('active');
                
                const spans = menuToggle.querySelectorAll('span');
                spans.forEach(span => span.classList.remove('active'));
            });
        });
    }
    
    function closeMenuOnClickOutside(event) {
        if (!mainNav.contains(event.target) && !menuToggle.contains(event.target)) {
            mainNav.classList.remove('active');
            
            const spans = menuToggle.querySelectorAll('span');
            spans.forEach(span => span.classList.remove('active'));
            
            document.removeEventListener('click', closeMenuOnClickOutside);
        }
    }
}

/**
 * Menu Category Filter
 */
function initMenuFilter() {
    const menuCategories = document.querySelectorAll('.menu-category');
    const menuItems = document.querySelectorAll('.menu-item');
    
    if (menuCategories.length && menuItems.length) {
        menuCategories.forEach(category => {
            category.addEventListener('click', function() {
                // Remove active class from all categories
                menuCategories.forEach(cat => cat.classList.remove('active'));
                
                // Add active class to clicked category
                this.classList.add('active');
                
                const selectedCategory = this.getAttribute('data-category');
                
                // Filter menu items
                menuItems.forEach(item => {
                    if (selectedCategory === 'semua' || item.getAttribute('data-category') === selectedCategory) {
                        item.style.display = 'flex';
                        
                        // Add animation
                        item.classList.add('fade-in');
                        setTimeout(() => {
                            item.classList.remove('fade-in');
                        }, 500);
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
        });
    }
}

/**
 * Testimonial Slider
 */
function initTestimonialSlider() {
    const testimonialItems = document.querySelectorAll('.testimonial-item');
    const dots = document.querySelectorAll('.dot');
    const prevBtn = document.querySelector('.control-prev');
    const nextBtn = document.querySelector('.control-next');
    
    if (testimonialItems.length && dots.length && prevBtn && nextBtn) {
        let currentIndex = 0;
        
        // Hide all testimonials except the first one
        testimonialItems.forEach((item, index) => {
            if (index !== 0) {
                item.style.display = 'none';
            }
        });
        
        // Next button click
        nextBtn.addEventListener('click', function() {
            showTestimonial(currentIndex + 1);
        });
        
        // Previous button click
        prevBtn.addEventListener('click', function() {
            showTestimonial(currentIndex - 1);
        });
        
        // Dot click
        dots.forEach((dot, index) => {
            dot.addEventListener('click', function() {
                showTestimonial(index);
            });
        });
        
        // Auto slide every 5 seconds
        let slideInterval = setInterval(() => {
            showTestimonial(currentIndex + 1);
        }, 5000);
        
        // Pause auto slide on hover
        const testimonialSlider = document.querySelector('.testimonial-slider');
        if (testimonialSlider) {
            testimonialSlider.addEventListener('mouseenter', function() {
                clearInterval(slideInterval);
            });
            
            testimonialSlider.addEventListener('mouseleave', function() {
                slideInterval = setInterval(() => {
                    showTestimonial(currentIndex + 1);
                }, 5000);
            });
        }
        
        function showTestimonial(index) {
            // Handle index bounds
            if (index >= testimonialItems.length) {
                index = 0;
            } else if (index < 0) {
                index = testimonialItems.length - 1;
            }
            
            // Hide current testimonial
            testimonialItems[currentIndex].style.display = 'none';
            dots[currentIndex].classList.remove('active');
            
            // Show new testimonial
            testimonialItems[index].style.display = 'block';
            dots[index].classList.add('active');
            
            // Update current index
            currentIndex = index;
        }
    }
}

/**
 * Scroll Animation
 */
function initScrollAnimation() {
    // Smooth scroll for anchor links
    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    
    anchorLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                const headerHeight = document.querySelector('.header').offsetHeight;
                const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Reveal elements on scroll
    const revealElements = document.querySelectorAll('.feature-item, .menu-item, .service-card, .package-card, .about-content, .testimonial-item');
    
    function revealOnScroll() {
        const windowHeight = window.innerHeight;
        const revealPoint = 150;
        
        revealElements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top;
            
            if (elementTop < windowHeight - revealPoint) {
                element.classList.add('revealed');
            }
        });
    }
    
    // Initial check
    revealOnScroll();
    
    // Check on scroll
    window.addEventListener('scroll', revealOnScroll);
}

/**
 * Form Validation
 */
function initFormValidation() {
    const orderForm = document.getElementById('orderForm');
    
    if (orderForm) {
        orderForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form fields
            const name = document.getElementById('name');
            const email = document.getElementById('email');
            const phone = document.getElementById('phone');
            const eventType = document.getElementById('eventType');
            const eventDate = document.getElementById('eventDate');
            const guestCount = document.getElementById('guestCount');
            const serviceType = document.getElementById('serviceType');
            
            // Validate fields
            let isValid = true;
            
            // Name validation
            if (name.value.trim() === '') {
                showError(name, 'Nama tidak boleh kosong');
                isValid = false;
            } else {
                removeError(name);
            }
            
            // Email validation
            if (email.value.trim() === '') {
                showError(email, 'Email tidak boleh kosong');
                isValid = false;
            } else if (!isValidEmail(email.value)) {
                showError(email, 'Format email tidak valid');
                isValid = false;
            } else {
                removeError(email);
            }
            
            // Phone validation
            if (phone.value.trim() === '') {
                showError(phone, 'Nomor telepon tidak boleh kosong');
                isValid = false;
            } else {
                removeError(phone);
            }
            
            // Event type validation
            if (eventType.value === '') {
                showError(eventType, 'Pilih jenis acara');
                isValid = false;
            } else {
                removeError(eventType);
            }
            
            // Event date validation
            if (eventDate.value === '') {
                showError(eventDate, 'Pilih tanggal acara');
                isValid = false;
            } else {
                removeError(eventDate);
            }
            
            // Guest count validation
            if (guestCount.value === '' || guestCount.value < 10) {
                showError(guestCount, 'Jumlah tamu minimal 10 orang');
                isValid = false;
            } else {
                removeError(guestCount);
            }
            
            // Service type validation
            if (serviceType.value === '') {
                showError(serviceType, 'Pilih jenis layanan');
                isValid = false;
            } else {
                removeError(serviceType);
            }
            
            // If form is valid, show success message
            if (isValid) {
                // In a real application, you would submit the form data to a server here
                // For this demo, we'll just show a success message
                orderForm.innerHTML = `
                    <div class="success-message">
                        <h3>Terima Kasih!</h3>
                        <p>Pesanan Anda telah kami terima. Tim kami akan menghubungi Anda dalam 24 jam untuk konfirmasi.</p>
                        <button type="button" class="btn-primary" onclick="location.reload()">Kembali</button>
                    </div>
                `;
            }
        });
    }
    
    // Helper functions for form validation
    function showError(input, message) {
        const formGroup = input.parentElement;
        const errorElement = formGroup.querySelector('.error-message') || document.createElement('div');
        
        errorElement.className = 'error-message';
        errorElement.textContent = message;
        
        if (!formGroup.querySelector('.error-message')) {
            formGroup.appendChild(errorElement);
        }
        
        input.classList.add('error');
    }
    
    function removeError(input) {
        const formGroup = input.parentElement;
        const errorElement = formGroup.querySelector('.error-message');
        
        if (errorElement) {
            formGroup.removeChild(errorElement);
        }
        
        input.classList.remove('error');
    }
    
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
}

/**
 * Header Scroll Effect
 */
function initHeaderScroll() {
    const header = document.querySelector('.header');
    
    if (header) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }
}

// Add CSS for JavaScript-dependent styles
const styleElement = document.createElement('style');
styleElement.textContent = `
    /* Animation classes */
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .fade-in {
        animation: fadeIn 0.5s ease forwards;
    }
    
    /* Mobile menu active state */
    .mobile-menu-toggle span.active:nth-child(1) {
        transform: rotate(45deg) translate(5px, 5px);
    }
    
    .mobile-menu-toggle span.active:nth-child(2) {
        opacity: 0;
    }
    
    .mobile-menu-toggle span.active:nth-child(3) {
        transform: rotate(-45deg) translate(7px, -7px);
    }
    
    /* Header scroll effect */
    .header.scrolled {
        padding: 10px 0;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }
    
    /* Form validation styles */
    .error-message {
        color: #e74c3c;
        font-size: 0.85rem;
        margin-top: 5px;
    }
    
    input.error, select.error, textarea.error {
        border-color: #e74c3c;
    }
    
    /* Success message */
    .success-message {
        text-align: center;
        padding: 30px;
    }
    
    .success-message h3 {
        color: #27ae60;
        margin-bottom: 15px;
    }
    
    .success-message p {
        margin-bottom: 20px;
    }
    
    /* Reveal animation */
    .feature-item, .menu-item, .service-card, .package-card, .about-content, .testimonial-item {
        opacity: 0;
        transform: translateY(30px);
        transition: opacity 0.6s ease, transform 0.6s ease;
    }
    
    .feature-item.revealed, .menu-item.revealed, .service-card.revealed, .package-card.revealed, .about-content.revealed, .testimonial-item.revealed {
        opacity: 1;
        transform: translateY(0);
    }
`;

document.head.appendChild(styleElement);
